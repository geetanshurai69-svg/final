
(() => {
  if (window.top !== window) return;

  let lastScrollY = window.scrollY;
  let lastTime = performance.now();
  let lastActivity = performance.now();
  let velocities = [];
  let pauses = [];
  let sessionStart = Date.now();
  let lastState = "Normal";
  let spiralShown = false;
  const windowMs = 20000;

  const clamp = (n,a,b) => Math.max(a, Math.min(b,n));

  function stateFromSignals(avgVelocity, dwell, burstCount, sensitivity=60) {
    const velocityScore = clamp((avgVelocity - 350) / 1650 * 100, 0, 100);
    const dwellScore = clamp((3.5 - dwell) / 3.5 * 100, 0, 100);
    const burstScore = clamp(burstCount / 10 * 100, 0, 100);
    const score = Math.round(velocityScore*.45 + dwellScore*.25 + burstScore*.30);
    const threshold = sensitivity;
    let state = "Normal";
    if (score >= threshold + 18) state = "Spiral detected";
    else if (score >= threshold) state = "Possible spiral";
    else if (score >= threshold - 18) state = "Focused";
    return {state, score};
  }

  function emit(state, score, velocity, dwell) {
    const payload = {
      state, score, velocity, dwell,
      site: location.hostname,
      previousState: lastState,
      sessionStart: Date.now() - sessionStart < 1500
    };
    chrome.runtime.sendMessage({type:"SPIRAL_EVENT", payload}).catch(()=>{});
    window.dispatchEvent(new CustomEvent("spiralsense:analytics", {detail: payload}));
    lastState = state;
  }

  function overlay() {
    if (spiralShown) return;
    spiralShown = true;
    const el = document.createElement("div");
    el.id = "spiralsense-overlay";
    el.innerHTML = `
      <div class="ss-card">
        <div class="ss-pill">Spiral detected</div>
        <h2>You may be entering a scrolling spiral.</h2>
        <p>High velocity and short pauses have formed a sustained pattern.</p>
        <div class="ss-actions">
          <button id="ss-continue">Continue</button>
          <button id="ss-break">Take a break</button>
        </div>
      </div>`;
    document.documentElement.appendChild(el);
    el.querySelector("#ss-continue").onclick=()=>{el.remove(); spiralShown=false;};
    el.querySelector("#ss-break").onclick=()=>{
      el.querySelector(".ss-card").innerHTML=`<div class="ss-pill">Break started</div><h2>Nice pause.</h2><p>Take two minutes before returning.</p>`;
      setTimeout(()=>{el.remove(); spiralShown=false;}, 120000);
    };
  }

  function onScroll() {
    const now = performance.now();
    const dt = Math.max(16, now-lastTime);
    const dy = Math.abs(window.scrollY-lastScrollY);
    const velocity = dy / dt * 1000;
    const gap = now-lastActivity;
    if (gap > 900) pauses.push(Math.min(20, gap/1000));
    velocities.push({t: now, v: velocity});
    const cutoff = now-windowMs;
    velocities = velocities.filter(x=>x.t>=cutoff);
    pauses = pauses.filter((_,i)=>i>Math.max(0,pauses.length-20));
    const avg = velocities.reduce((a,x)=>a+x.v,0)/Math.max(1,velocities.length);
    const dwell = pauses.length ? pauses.reduce((a,b)=>a+b,0)/pauses.length : Math.max(0.5,(now-lastActivity)/1000);
    const bursts = velocities.filter(x=>x.v>700).length;
    chrome.storage.local.get("settings").then(({settings})=>{
      const s=stateFromSignals(avg,dwell,bursts,settings?.sensitivity ?? 60);
      emit(s.state,s.score,avg,dwell);
      if(s.state==="Spiral detected") overlay();
    });
    lastScrollY=window.scrollY; lastTime=now; lastActivity=now;
  }
  window.addEventListener("scroll", onScroll, {passive:true});

  // Bridge extension data into the dashboard page without exposing extension APIs to page JS.
  // Dashboard bridge: the website asks the content script for local extension analytics.
  if (location.hostname.includes("spiral-scout") || location.hostname.includes("lovable")) {
    const sync = () => chrome.runtime.sendMessage({type:"GET_ANALYTICS"}).then(data => {
      window.dispatchEvent(new CustomEvent("spiralsense:sync", {detail:data}));
    }).catch(()=>{});
    sync();
    setInterval(sync, 2000);
    window.addEventListener("spiralsense:request-sync", sync);
  }
})();
