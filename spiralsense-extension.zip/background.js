
const DEFAULTS = {
  settings: { sensitivity: 60, enabled: true },
  today: { date: new Date().toISOString().slice(0,10), spirals: 0, sessions: 0, focusMinutes: 0 },
  history: [],
  current: { state: "Normal", score: 0, velocity: 0, dwell: 0, updatedAt: Date.now() }
};

chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const patch = {};
  for (const [k,v] of Object.entries(DEFAULTS)) if (data[k] === undefined) patch[k] = v;
  await chrome.storage.local.set(patch);
});

async function saveEvent(event) {
  const d = await chrome.storage.local.get(["today","history","current","settings"]);
  const today = d.today || DEFAULTS.today;
  const date = new Date().toISOString().slice(0,10);
  if (today.date !== date) {
    today.date = date; today.spirals = 0; today.sessions = 0; today.focusMinutes = 0;
  }
  if (event.state === "Spiral detected" && event.previousState !== "Spiral detected") today.spirals++;
  if (event.sessionStart) today.sessions++;
  if (event.focusMinutes) today.focusMinutes += event.focusMinutes;

  const current = {
    state: event.state || "Normal",
    score: Math.round(event.score || 0),
    velocity: Math.round(event.velocity || 0),
    dwell: Number((event.dwell || 0).toFixed(1)),
    updatedAt: Date.now()
  };

  const history = Array.isArray(d.history) ? d.history : [];
  history.push({
    ts: Date.now(),
    state: current.state,
    score: current.score,
    velocity: current.velocity,
    dwell: current.dwell,
    site: event.site || "Unknown"
  });
  while (history.length > 500) history.shift();

  await chrome.storage.local.set({ today, current, history });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "SPIRAL_EVENT") {
    saveEvent(msg.payload).then(() => sendResponse({ok:true}));
    return true;
  }
  if (msg?.type === "GET_ANALYTICS") {
    chrome.storage.local.get(["today","history","current","settings"]).then(sendResponse);
    return true;
  }
});
