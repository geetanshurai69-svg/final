
async function load(){
 const d=await chrome.storage.local.get(["current","today"]);
 const c=d.current||{}, t=d.today||{};
 document.getElementById("state").textContent=c.state||"Normal";
 document.getElementById("score").textContent=Math.round(c.score||0);
 document.getElementById("velocity").textContent=Math.round(c.velocity||0).toLocaleString();
 document.getElementById("dwell").textContent=Number(c.dwell||0).toFixed(1);
 document.getElementById("spirals").textContent=`${t.spirals||0} spirals`;
}
load();
document.getElementById("dashboard").onclick=()=>{
 chrome.tabs.create({url:"https://spiral-scout.lovable.app/extension"});
};
